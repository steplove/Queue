export const number_B = "နံပါတ်"; //หมายเลข
export const room_B = "စစ်ဆေးအခန်း"; //ห้องตรวจ
export const waiting_call_B = "စောင့်နေသည့် နံပါတ်"; //รอเรียกตรวจ
export const inroom = "စစ်ဆေးအခန်းထဲသို့ဝင်"; //เข้าห้องตรวจ
export const payment_room = "ငွေပေးချေမှုအခန်း"; //ห้องจ่ายเงิน
export const pharmacy_room = "ဆေးခန်း"; //ห้องรับยา
export const waiting_for_payment = "ငွေပေးချေမှုကို စောင့်နေသည်"; //รอจ่ายเงิน
export const waiting_for_medicine = "ဆေးကို စောင့်နေသည်"; //รอรับยา
